const highscore = {
  bestScore: 0,
  bestComplete: 0
};

export default highscore;
